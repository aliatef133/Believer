<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = htmlspecialchars($_POST['name']);
    $email = htmlspecialchars($_POST['email']);
    $message = htmlspecialchars($_POST['message']);

    echo '<!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Message Sent</title>
      <style>
        body { display:flex; justify-content:center; align-items:center; min-height:100vh; font-family:sans-serif; background:#f0f4f8; }
        .success-box { background:#fff; padding:40px; border-radius:20px; box-shadow:0 10px 30px rgba(0,0,0,0.2); text-align:center; }
        h2 { color:#2575fc; margin-bottom:15px; }
        p { font-size:16px; line-height:1.5; }
        a { display:inline-block; margin-top:20px; text-decoration:none; color:#fff; background:#2575fc; padding:10px 20px; border-radius:12px; transition:0.3s; }
        a:hover { background:#6a11cb; }
      </style>
    </head>
    <body>
      <div class="success-box">
        <h2>تم إرسال الرسالة بنجاح!</h2>
        <p>شكرًا لك، '.$name.'. سأرد عليك قريبًا على بريدك '.$email.'.</p>
        <a href="contact.html">عودة للنموذج</a>
      </div>
    </body>
    </html>';
} else {
    http_response_code(405);
    echo "<h2>الطريقة غير مسموحة</h2>";
}
?>
