 // Import the functions you need from the SDKs you need
  import { initializeApp } from "https://www.gstatic.com/firebasejs/12.2.1/firebase-app.js";
  // TODO: Add SDKs for Firebase products that you want to use
  // https://firebase.google.com/docs/web/setup#available-libraries

  // Your web app's Firebase configuration
  const firebaseConfig = {
    apiKey: "AIzaSyDaiUbZuTH6r1_PbXSCJ36Dybs9eqsBpo8",
    authDomain: "beliver-ebe80.firebaseapp.com",
    projectId: "beliver-ebe80",
    storageBucket: "beliver-23e5d.appspot.com",
    messagingSenderId: "998487933471",
    appId: "1:998487933471:web:ea6d31f9e43521ccea0b2a"
  };

  // Initialize Firebase
  const app = initializeApp(firebaseConfig);