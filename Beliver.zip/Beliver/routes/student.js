const mongoose = require('mongoose');

const studentSchema = new mongoose.Schema({
    name: { type: String, required: true },
    stage: { type: String, required: true },
    code: { type: String, required: true },
    paid: { type: Boolean, default: false }
});

module.exports = mongoose.model('Student', studentSchema);
