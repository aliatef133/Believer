const express = require('express');
const router = express.Router();
const Student = require('../models/Student');
const Video = require('../models/Video');

// توليد كود بعد الدفع
router.post('/getCode', async (req, res) => {
    const { name, stage } = req.body;
    if (!name || !stage) return res.status(400).json({ msg: 'Name and stage required' });

    const code = Math.floor(100000 + Math.random() * 900000).toString();

    const student = new Student({ name, stage, code, paid: true });
    await student.save();

    res.json({ code });
});

// التحقق من الكود
router.post('/verifyCode', async (req, res) => {
    const { name, stage, code } = req.body;
    const student = await Student.findOne({ name, stage, code, paid: true });
    if (!student) return res.status(400).json({ msg: 'Invalid code' });

    const videos = await Video.find({ stage });
    res.json({ videos });
});

module.exports = router;
