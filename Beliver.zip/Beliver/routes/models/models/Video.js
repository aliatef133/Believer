const mongoose = require('mongoose');

const videoSchema = new mongoose.Schema({
    stage: { type: String, required: true },
    filename: { type: String, required: true },
});

module.exports = mongoose.model('Video', videoSchema);
