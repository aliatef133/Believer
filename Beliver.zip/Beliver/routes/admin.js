const express = require('express');
const router = express.Router();
const multer = require('multer');
const Video = require('../models/Video');

// إعداد multer لتخزين الفيديوهات
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'uploads/');
    },
    filename: function (req, file, cb) {
        cb(null, Date.now() + '-' + file.originalname);
    }
});
const upload = multer({ storage });

// رفع فيديو للمرحلة
router.post('/uploadVideo', upload.single('video'), async (req, res) => {
    const { stage } = req.body;
    if (!stage || !req.file) return res.status(400).json({ msg: 'Stage and video file required' });

    const video = new Video({
        stage,
        filename: req.file.filename,
        originalName: req.file.originalname
    });

    await video.save();
    res.json({ msg: 'Video uploaded successfully', video });
});

module.exports = router;
