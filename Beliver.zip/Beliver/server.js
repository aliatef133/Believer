const express = require('express');
const multer  = require('multer');
const fs = require('fs');
const path = require('path');

const app = express();
const upload = multer({ dest: 'uploads/' });

app.use(express.static(__dirname)); // يقدّم index.html

// تخزين مؤقت لبيانات الفيديوهات
let videos = [];

// مسار رفع الفيديو
app.post('/upload', upload.single('video'), (req, res) => {
  if (!req.file || !req.body.title || !req.body.stage) {
    return res.json({ success: false, message: 'missing fields' });
  }

  const fileUrl = '/uploads/' + req.file.filename;
  videos.push({
    title: req.body.title,
    stage: req.body.stage,
    url: fileUrl
  });
  res.json({ success: true });
});

// مسار استرجاع الفيديوهات
app.get('/videos', (req, res) => {
  res.json(videos);
});

app.use('/uploads', express.static(path.join(__dirname,'uploads')));

app.listen(3000, () => console.log('Server running at http://localhost:3000'));
